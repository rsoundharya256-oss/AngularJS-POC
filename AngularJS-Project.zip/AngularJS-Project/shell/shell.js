import { registerApplication, start } from 'single-spa';

// Global navigation functions
window.navigateTo = function(path) {
    console.log('Navigating to:', path);
    window.history.pushState({}, '', path);
    window.dispatchEvent(new PopStateEvent('popstate'));
    updateFrameworkIndicator();
};

window.logout = function() {
    if (window.authService) {
        window.authService.logout();
    }
    window.navigateTo('/login');
};

// Update framework indicator
function updateFrameworkIndicator() {
    const indicator = document.getElementById('framework-indicator');
    const path = window.location.pathname;
    
    if (path === '/login' || path === '/legacy') {
        indicator.textContent = 'AngularJS';
        indicator.className = 'framework-indicator angularjs-indicator';
    } else {
        indicator.textContent = 'React';
        indicator.className = 'framework-indicator react-indicator';
    }
}

// Show error message
function showError(message) {
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');
    
    errorMessage.textContent = message;
    errorContainer.style.display = 'block';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        errorContainer.style.display = 'none';
    }, 5000);
}

// Hide error message
function hideError() {
    document.getElementById('error-container').style.display = 'none';
}

// Register AngularJS application
registerApplication({
    name: 'angularjs-app',
    app: () => {
        return new Promise((resolve, reject) => {
            try {
                // Load AngularJS app dynamically
                const script = document.createElement('script');
                script.src = '../angularjs-app/app/app.js';
                script.onload = () => {
                    // Load all AngularJS components
                    const componentScripts = [
                        '../angularjs-app/app/components/About/AboutModule.js',
                        '../angularjs-app/app/components/About/AboutController.js',
                        '../angularjs-app/app/components/About/AboutRoute.js',
                        '../angularjs-app/app/components/About/AboutService.js',
                        '../angularjs-app/app/components/Contact/ContactModule.js',
                        '../angularjs-app/app/components/Contact/ContactController.js',
                        '../angularjs-app/app/components/Contact/ContactRoute.js',
                        '../angularjs-app/app/components/Contact/ContactService.js',
                        '../angularjs-app/app/components/Selling/SellingModule.js',
                        '../angularjs-app/app/components/Selling/SellingController.js',
                        '../angularjs-app/app/components/Selling/SellingRoute.js',
                        '../angularjs-app/app/components/Selling/SellingService.js',
                        '../angularjs-app/app/components/Selling/SellingTemplateDirective.js',
                        '../angularjs-app/app/app.service.js',
                        '../angularjs-app/app/app.controller.js',
                        '../angularjs-app/app/app.constants.js',
                        '../angularjs-app/app/app.route.js',
                        '../angularjs-app/app/app.run.js',
                        '../angularjs-app/app/app.values.js'
                    ];
                    
                    let loadedScripts = 0;
                    const totalScripts = componentScripts.length;
                    
                    componentScripts.forEach(scriptPath => {
                        const componentScript = document.createElement('script');
                        componentScript.src = scriptPath;
                        componentScript.onload = () => {
                            loadedScripts++;
                            if (loadedScripts === totalScripts) {
                                // Initialize AngularJS app
                                const angularjsRoot = document.getElementById('angularjs-root');
                                angularjsRoot.innerHTML = `
                                    <div ng-app="TemplateSellingApp" ng-controller="TemplateController">
                                        <div ui-view></div>
                                    </div>
                                `;
                                
                                // Bootstrap AngularJS
                                angular.bootstrap(angularjsRoot, ['TemplateSellingApp']);
                                resolve();
                            }
                        };
                        componentScript.onerror = () => {
                            console.warn('Failed to load script:', scriptPath);
                            loadedScripts++;
                            if (loadedScripts === totalScripts) {
                                resolve();
                            }
                        };
                        document.head.appendChild(componentScript);
                    });
                };
                script.onerror = reject;
                document.head.appendChild(script);
            } catch (error) {
                console.error('Error loading AngularJS app:', error);
                reject(error);
            }
        });
    },
    activeWhen: ['/login', '/legacy'],
    customProps: {
        domElement: document.getElementById('angularjs-root')
    }
});

// Register React application
registerApplication({
    name: 'react-app',
    app: () => {
        return new Promise((resolve, reject) => {
            try {
                // Load React app dynamically
                const script = document.createElement('script');
                script.src = '../react-app/dist/react-app.js';
                script.onload = () => {
                    if (window.ReactApp) {
                        resolve(window.ReactApp);
                    } else {
                        reject(new Error('React app not found'));
                    }
                };
                script.onerror = () => {
                    // Fallback: create a simple React app placeholder
                    const reactRoot = document.getElementById('react-root');
                    reactRoot.innerHTML = `
                        <div class="alert alert-info">
                            <h4>React App Placeholder</h4>
                            <p>React micro-frontend is being loaded...</p>
                            <p>This would normally contain the React application.</p>
                            <button class="btn btn-primary" onclick="window.navigateTo('/templates')">
                                Go to Templates
                            </button>
                        </div>
                    `;
                    resolve();
                };
                document.head.appendChild(script);
            } catch (error) {
                console.error('Error loading React app:', error);
                reject(error);
            }
        });
    },
    activeWhen: ['/templates', '/payment', '/contact', '/about', '/'],
    customProps: {
        domElement: document.getElementById('react-root')
    }
});

// Handle route changes
window.addEventListener('popstate', function(event) {
    const path = window.location.pathname;
    console.log('Route changed to:', path);
    
    // Show/hide micro-frontends based on route
    const angularjsRoot = document.getElementById('angularjs-root');
    const reactRoot = document.getElementById('react-root');
    
    if (path === '/login' || path === '/legacy') {
        angularjsRoot.style.display = 'block';
        reactRoot.style.display = 'none';
        hideError();
    } else {
        angularjsRoot.style.display = 'none';
        reactRoot.style.display = 'block';
        hideError();
    }
    
    updateFrameworkIndicator();
});

// Handle application errors
window.addEventListener('single-spa:before-routing-event', (evt) => {
    hideError();
});

window.addEventListener('single-spa:routing-event', (evt) => {
    console.log('Single-SPA routing event:', evt.detail);
});

// Global error handler
window.addEventListener('error', (evt) => {
    console.error('Global error:', evt.error);
    showError(evt.error.message || 'An unexpected error occurred');
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Shell application initialized');
    
    // Initialize shared services
    if (window.authService) {
        window.authService.initialize();
    }
    
    // Set initial route
    const initialPath = window.location.pathname;
    if (initialPath === '/') {
        window.navigateTo('/templates');
    } else {
        updateFrameworkIndicator();
    }
    
    // Start single-spa
    start().then(() => {
        console.log('Single-SPA started successfully');
    }).catch(error => {
        console.error('Failed to start Single-SPA:', error);
        showError('Failed to initialize application');
    });
});

// Export for module systems
export { navigateTo, logout, updateFrameworkIndicator, showError, hideError };
