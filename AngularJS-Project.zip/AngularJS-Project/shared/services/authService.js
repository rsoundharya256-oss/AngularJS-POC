class AuthService {
    constructor() {
        this.token = localStorage.getItem('authToken');
        this.user = null;
        this.listeners = [];
    }
    
    async login(credentials) {
        try {
            // Simulate API call with delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Hardcoded authentication for demo (matching existing AngularJS logic)
            if (credentials.username === 'admin' && credentials.password === 'password') {
                this.token = 'demo-token-' + Date.now();
                this.user = { 
                    username: 'admin', 
                    role: 'user',
                    id: 1
                };
                
                localStorage.setItem('authToken', this.token);
                this.notifyListeners('login', this.user);
                
                return { success: true, user: this.user };
            } else {
                throw new Error('Invalid credentials');
            }
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, error: error.message };
        }
    }
    
    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('authToken');
        this.notifyListeners('logout');
        
        // Dispatch global logout event
        window.dispatchEvent(new CustomEvent('auth-logout'));
    }
    
    isAuthenticated() {
        return !!this.token;
    }
    
    getCurrentUser() {
        return this.user;
    }
    
    getToken() {
        return this.token;
    }
    
    subscribe(listener) {
        this.listeners.push(listener);
        return () => {
            this.listeners = this.listeners.filter(l => l !== listener);
        };
    }
    
    notifyListeners(event, data) {
        this.listeners.forEach(listener => {
            try {
                listener(event, data);
            } catch (error) {
                console.error('Error in auth listener:', error);
            }
        });
    }
    
    // Initialize auth state from localStorage
    initialize() {
        if (this.token) {
            this.user = { 
                username: 'admin', 
                role: 'user',
                id: 1
            };
            this.notifyListeners('login', this.user);
        }
    }
}

// Create singleton instance
const authService = new AuthService();

// Export for both CommonJS and ES modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AuthService;
    module.exports.default = AuthService;
    module.exports.authService = authService;
} else if (typeof window !== 'undefined') {
    window.AuthService = AuthService;
    window.authService = authService;
}

// Initialize when loaded
if (typeof window !== 'undefined') {
    authService.initialize();
}
