class TemplateService {
    constructor() {
        this.templates = null;
        this.cache = new Map();
    }
    
    async getTemplates() {
        if (this.templates) {
            return this.templates;
        }
        
        try {
            // Try to load from the existing AngularJS assets
            const response = await fetch('/angularjs-app/assets/json/template_data.json');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            this.templates = data.template_data.map((template, index) => ({
                ...template,
                id: index + 1,
                slug: template.Name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
            }));
            
            return this.templates;
        } catch (error) {
            console.error('Error loading templates:', error);
            
            // Fallback to hardcoded templates if fetch fails
            this.templates = [
                {
                    id: 1,
                    slug: 'log-in-template',
                    Name: 'Log-In Template',
                    Features: ['Interactive UX', 'Awesome design', 'Budget friendly'],
                    Description: 'A simple yet attractive LogIn template',
                    Price: '$10',
                    Src: '/angularjs-app/assets/images/login.jpg'
                },
                {
                    id: 2,
                    slug: 'sign-up-template',
                    Name: 'Sign-Up Template',
                    Features: ['Interactive UX', 'Awesome design', 'Budget friendly'],
                    Description: 'A simple yet attractive Sign-Up template',
                    Price: '$10',
                    Src: '/angularjs-app/assets/images/signup.jpg'
                },
                {
                    id: 3,
                    slug: 'e-commerce-template',
                    Name: 'e-Commerce Template',
                    Features: ['Interactive UX', 'PayPal Enabled', 'Secure Payment'],
                    Description: 'A simple yet attractive e-Commerce template',
                    Price: '$30',
                    Src: '/angularjs-app/assets/images/ecommerce.png'
                },
                {
                    id: 4,
                    slug: 'contact-us-template',
                    Name: 'Contact-Us Template',
                    Features: ['Interactive UX', 'Awesome design', 'Budget friendly'],
                    Description: 'A simple yet attractive Contact template',
                    Price: '$10',
                    Src: '/angularjs-app/assets/images/contactus.jpg'
                },
                {
                    id: 5,
                    slug: 'about-us-template',
                    Name: 'About-Us Template',
                    Features: ['Interactive UX', 'Awesome design', 'Budget friendly'],
                    Description: 'A simple yet attractive About template',
                    Price: '$10',
                    Src: '/angularjs-app/assets/images/aboutus.jpg'
                },
                {
                    id: 6,
                    slug: 'buy-now-template',
                    Name: 'Buy-Now Template',
                    Features: ['Interactive UX', 'PayPal Enabled', 'Secure Payment'],
                    Description: 'A simple yet attractive Shopping template',
                    Price: '$30',
                    Src: '/angularjs-app/assets/images/buynow.jpg'
                }
            ];
            
            return this.templates;
        }
    }
    
    async getTemplateById(id) {
        const templates = await this.getTemplates();
        return templates.find(template => template.id === parseInt(id));
    }
    
    async getTemplateBySlug(slug) {
        const templates = await this.getTemplates();
        return templates.find(template => template.slug === slug);
    }
    
    async processPayment(paymentData) {
        try {
            // Simulate payment processing with delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            const transactionId = 'TXN' + Date.now();
            const result = {
                success: true,
                transactionId,
                amount: paymentData.amount,
                template: paymentData.template,
                timestamp: new Date().toISOString(),
                cardLastFour: paymentData.cardNumber ? paymentData.cardNumber.slice(-4) : '****'
            };
            
            // Cache the transaction
            this.cache.set(transactionId, result);
            
            return result;
        } catch (error) {
            console.error('Payment error:', error);
            throw error;
        }
    }
    
    async submitContact(contactData) {
        try {
            // Simulate contact form submission
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const result = {
                success: true,
                messageId: 'MSG' + Date.now(),
                timestamp: new Date().toISOString(),
                data: contactData
            };
            
            return result;
        } catch (error) {
            console.error('Contact submission error:', error);
            throw error;
        }
    }
    
    getTransaction(transactionId) {
        return this.cache.get(transactionId);
    }
    
    clearCache() {
        this.templates = null;
        this.cache.clear();
    }
}

// Create singleton instance
const templateService = new TemplateService();

// Export for both CommonJS and ES modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TemplateService;
    module.exports.default = TemplateService;
    module.exports.templateService = templateService;
} else if (typeof window !== 'undefined') {
    window.TemplateService = TemplateService;
    window.templateService = templateService;
}
