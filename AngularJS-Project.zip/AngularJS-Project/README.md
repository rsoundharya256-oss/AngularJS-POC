# Template Selling Website - Micro-Frontend Architecture

A modern micro-frontend architecture that combines AngularJS and React applications, enabling incremental migration from legacy AngularJS to modern React.

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Main Application Shell                    │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   AngularJS     │  │     React       │  │   Shared     │ │
│  │   Micro-Frontend│  │  Micro-Frontend │  │   Services   │ │
│  │                 │  │                 │  │             │ │
│  │ • Login         │  │ • Template      │  │ • Auth      │ │
│  │ • Navigation    │  │   Display       │  │ • API       │ │
│  │ • Legacy        │  │ • Payment       │  │ • State     │ │
│  │   Components    │  │ • Modern UI     │  │   Management│ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- npm 8+

### Installation

1. **Clone and setup:**
   ```bash
   cd "AngularJS-Project"
   chmod +x scripts/setup.sh
   ./scripts/setup.sh
   ```

2. **Start development servers:**
   ```bash
   npm run dev
   ```

3. **Open your browser:**
   - Main Application: http://localhost:3000
   - React App: http://localhost:3001
   - AngularJS App: http://localhost:3002

4. **Login with demo credentials:**
   - Username: `admin`
   - Password: `password`

## 📁 Project Structure

```
AngularJS-Project/
├── angularjs-app/          # AngularJS micro-frontend
│   ├── app/               # AngularJS application files
│   ├── assets/            # Static assets
│   ├── package.json       # AngularJS dependencies
│   └── webpack.config.js  # AngularJS build config
├── react-app/             # React micro-frontend
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── services/      # React services
│   │   └── index.js       # React entry point
│   ├── package.json       # React dependencies
│   └── webpack.config.js  # React build config
├── shared/                # Shared services
│   ├── services/          # Authentication & template services
│   └── utils/             # Event bus & utilities
├── shell/                 # Main application shell
│   ├── index.html         # Main HTML file
│   ├── shell.js           # Shell application logic
│   ├── package.json       # Shell dependencies
│   └── webpack.config.js  # Shell build config
├── scripts/               # Development scripts
│   ├── setup.sh           # Initial setup script
│   ├── dev.sh             # Development server script
│   └── build.sh           # Build script
└── package.json           # Root workspace configuration
```

## 🛠️ Available Commands

### Development
```bash
npm run dev              # Start all development servers
npm run dev:shell        # Start shell application only
npm run dev:react        # Start React app only
npm run dev:angularjs    # Start AngularJS app only
```

### Building
```bash
npm run build            # Build all applications
npm run build:shell      # Build shell application
npm run build:react      # Build React app
npm run build:angularjs  # Build AngularJS app
```

### Production
```bash
npm start                # Start production server
```

### Setup
```bash
npm run setup            # Run initial setup
./scripts/setup.sh       # Manual setup script
```

## 🎯 Features

### ✅ Implemented
- **Micro-Frontend Architecture** using Single-SPA
- **Shared Authentication** between AngularJS and React
- **Template Display** in React with modern UI
- **Payment Gateway** in React with form validation
- **Contact Form** in React with validation
- **About Page** in React with team information
- **Cross-Framework Communication** via events
- **Responsive Design** with Bootstrap
- **Development Environment** with hot reloading

### 🔄 Migration Status
- **AngularJS Components:**
  - ✅ Login System (integrated with shared auth)
  - ✅ Navigation (shared between frameworks)
  - ✅ Legacy components (preserved)

- **React Components:**
  - ✅ Template Display (modernized)
  - ✅ Payment Gateway (enhanced)
  - ✅ Contact Form (improved)
  - ✅ About Page (updated)

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the root directory:
```env
NODE_ENV=development
PORT=3000
REACT_APP_API_URL=http://localhost:8080
```

### Webpack Configuration
Each micro-frontend has its own webpack configuration:
- `shell/webpack.config.js` - Shell application
- `react-app/webpack.config.js` - React micro-frontend
- `angularjs-app/webpack.config.js` - AngularJS micro-frontend

## 🧪 Testing

### Manual Testing
1. **Authentication Flow:**
   - Login with admin/password
   - Verify shared authentication state
   - Test logout functionality

2. **Navigation:**
   - Test routing between AngularJS and React
   - Verify framework switching
   - Check URL updates

3. **Template Features:**
   - Browse templates in React
   - Select template for payment
   - Complete payment flow
   - Submit contact form

### Browser Testing
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 🚀 Deployment

### Development Deployment
```bash
npm run build
npm start
```

### Production Deployment
1. Build all applications:
   ```bash
   ./scripts/build.sh
   ```

2. Deploy the `shell/dist` directory to your web server

3. Configure your web server to serve static files from all dist directories

## 🔍 Troubleshooting

### Common Issues

1. **Port Conflicts:**
   - Shell: 3000
   - React: 3001
   - AngularJS: 3002
   - Change ports in webpack configs if needed

2. **CORS Issues:**
   - All webpack dev servers are configured with CORS headers
   - Check browser console for specific errors

3. **Module Loading Issues:**
   - Ensure all dependencies are installed
   - Run `npm run install:workspaces` to reinstall

4. **Authentication Issues:**
   - Check shared services are loaded
   - Verify localStorage is enabled
   - Use demo credentials: admin/password

### Debug Mode
Enable debug logging by opening browser console and running:
```javascript
localStorage.setItem('debug', 'true');
```

## 📚 Learning Resources

### Micro-Frontend Architecture
- [Single-SPA Documentation](https://single-spa.js.org/)
- [Micro-Frontend Patterns](https://martinfowler.com/articles/micro-frontends.html)

### Technology Stack
- [React Documentation](https://reactjs.org/docs/)
- [AngularJS Documentation](https://docs.angularjs.org/)
- [Webpack Documentation](https://webpack.js.org/)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For issues and questions:
1. Check the troubleshooting section
2. Review the browser console for errors
3. Create an issue with detailed information

---

**Happy coding! 🎉**
