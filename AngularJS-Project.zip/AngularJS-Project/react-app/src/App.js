import React from 'react';
import { Routes, Route } from 'react-router-dom';
import TemplateDisplay from './components/TemplateDisplay';
import PaymentGateway from './components/PaymentGateway';
import ContactForm from './components/ContactForm';
import AboutPage from './components/AboutPage';
import Navigation from './components/Navigation';

function App() {
    return (
        <div className="App">
            <Navigation />
            <Routes>
                <Route path="/templates" element={<TemplateDisplay />} />
                <Route path="/payment" element={<PaymentGateway />} />
                <Route path="/contact" element={<ContactForm />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/" element={<TemplateDisplay />} />
            </Routes>
        </div>
    );
}

export default App;
