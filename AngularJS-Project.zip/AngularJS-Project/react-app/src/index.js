import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';

// Single-SPA integration
if (window.singleSpaNavigate) {
    // Running in single-spa
    console.log('React app running in Single-SPA mode');
    
    // Export for Single-SPA
    window.ReactApp = {
        mount: (props) => {
            const { domElement } = props;
            const root = ReactDOM.createRoot(domElement);
            root.render(
                <BrowserRouter>
                    <App />
                </BrowserRouter>
            );
            return Promise.resolve();
        },
        unmount: () => {
            return Promise.resolve();
        }
    };
} else {
    // Running standalone
    console.log('React app running in standalone mode');
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(
        <BrowserRouter>
            <App />
        </BrowserRouter>
    );
}

// Also export for direct access
export default App;
