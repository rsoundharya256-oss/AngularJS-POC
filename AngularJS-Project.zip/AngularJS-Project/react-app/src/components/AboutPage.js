import React from 'react';

const AboutPage = () => {
    const teamMembers = [
        {
            name: 'Ravi',
            role: 'Lead Developer',
            image: '/angularjs-app/assets/images/ravi.jpg',
            description: 'Expert in frontend technologies and user experience design. Passionate about creating intuitive and beautiful web applications.'
        },
        {
            name: 'Saket',
            role: 'Backend Developer',
            image: '/angularjs-app/assets/images/saket.jpg',
            description: 'Specializes in backend architecture and database optimization. Focuses on building scalable and efficient server-side solutions.'
        }
    ];

    return (
        <div className="about-container">
            <h2>About Our Team</h2>
            <p>
                We are a dedicated team of developers passionate about creating beautiful and functional web templates. 
                Our mission is to provide high-quality templates that help businesses establish their online presence 
                quickly and efficiently.
            </p>
            
            <h3>Our Mission</h3>
            <p>
                To deliver exceptional web templates that combine modern design principles with practical functionality. 
                We believe that every business deserves a professional online presence, and our templates make that 
                achievable for everyone.
            </p>
            
            <h3>What We Offer</h3>
            <ul>
                <li><strong>High-Quality Templates:</strong> Professionally designed templates that are both beautiful and functional</li>
                <li><strong>Responsive Design:</strong> All templates work perfectly on desktop, tablet, and mobile devices</li>
                <li><strong>Easy Customization:</strong> Clean, well-documented code that's easy to modify</li>
                <li><strong>Affordable Pricing:</strong> Competitive prices that make professional web design accessible</li>
                <li><strong>Ongoing Support:</strong> We're here to help you succeed with your website</li>
            </ul>
            
            <h3>Meet Our Team</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '30px', justifyContent: 'center' }}>
                {teamMembers.map((member, index) => (
                    <div key={index} className="team-member">
                        <img 
                            src={member.image} 
                            alt={member.name}
                            onError={(e) => {
                                e.target.src = `https://via.placeholder.com/150x150?text=${member.name}`;
                            }}
                        />
                        <h4>{member.name}</h4>
                        <p><strong>{member.role}</strong></p>
                        <p>{member.description}</p>
                    </div>
                ))}
            </div>
            
            <h3>Why Choose Us?</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginTop: '20px' }}>
                <div style={{ padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
                    <h4>🚀 Fast Delivery</h4>
                    <p>Get your templates quickly with our instant download system.</p>
                </div>
                <div style={{ padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
                    <h4>💎 Premium Quality</h4>
                    <p>Every template is crafted with attention to detail and modern standards.</p>
                </div>
                <div style={{ padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
                    <h4>📱 Mobile Ready</h4>
                    <p>All templates are fully responsive and work on all devices.</p>
                </div>
                <div style={{ padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
                    <h4>🛠️ Easy to Use</h4>
                    <p>Clean code and documentation make customization simple.</p>
                </div>
            </div>
            
            <div style={{ marginTop: '40px', padding: '20px', backgroundColor: '#e9ecef', borderRadius: '8px' }}>
                <h4>Get Started Today</h4>
                <p>
                    Ready to create your professional website? Browse our collection of templates and find the perfect 
                    design for your business needs.
                </p>
                <button 
                    className="btn btn-primary"
                    onClick={() => window.navigateTo && window.navigateTo('/templates')}
                >
                    Browse Templates
                </button>
            </div>
        </div>
    );
};

export default AboutPage;
