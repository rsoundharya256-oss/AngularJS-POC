import React from 'react';

const Navigation = () => {
    const handleNavigate = (path) => {
        if (window.navigateTo) {
            window.navigateTo(path);
        } else {
            // Fallback for standalone mode
            window.location.href = path;
        }
    };

    return (
        <div className="navigation">
            <nav>
                <button 
                    className="nav-link" 
                    onClick={() => handleNavigate('/templates')}
                >
                    Templates
                </button>
                <button 
                    className="nav-link" 
                    onClick={() => handleNavigate('/contact')}
                >
                    Contact
                </button>
                <button 
                    className="nav-link" 
                    onClick={() => handleNavigate('/about')}
                >
                    About
                </button>
                <button 
                    className="nav-link" 
                    onClick={() => handleNavigate('/login')}
                >
                    Login (AngularJS)
                </button>
            </nav>
        </div>
    );
};

export default Navigation;
