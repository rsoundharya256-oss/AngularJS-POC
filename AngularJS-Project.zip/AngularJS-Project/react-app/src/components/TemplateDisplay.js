import React, { useState, useEffect } from 'react';

const TemplateDisplay = () => {
    const [templates, setTemplates] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        loadTemplates();
    }, []);

    const loadTemplates = async () => {
        setLoading(true);
        setError(null);
        
        try {
            if (window.templateService) {
                const templateData = await window.templateService.getTemplates();
                setTemplates(templateData);
            } else {
                // Fallback to direct fetch
                const response = await fetch('/angularjs-app/assets/json/template_data.json');
                if (!response.ok) {
                    throw new Error('Failed to load templates');
                }
                const data = await response.json();
                setTemplates(data.template_data || []);
            }
        } catch (err) {
            console.error('Error loading templates:', err);
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleBuyNow = (template) => {
        console.log('Buy now clicked for template:', template);
        
        // Dispatch event for shell to handle
        if (window.eventBus) {
            window.eventBus.emit('template-selected', template);
        }
        
        // Navigate to payment page
        if (window.navigateTo) {
            window.navigateTo('/payment');
        }
        
        // Store selected template for payment
        localStorage.setItem('selectedTemplate', JSON.stringify(template));
    };

    if (loading) {
        return <div className="loading">Loading templates...</div>;
    }

    if (error) {
        return (
            <div className="error">
                <strong>Error:</strong> {error}
                <button className="btn btn-primary" onClick={loadTemplates}>
                    Retry
                </button>
            </div>
        );
    }

    return (
        <div className="template-display">
            <h3>Choose the template that matches your business need</h3>
            <p className="h5">
                We have the best templates in store for you. Browse through a variety of stunning web templates 
                that are intuitive, easy to use and affordable. You can securely buy the template of your choice 
                in our online store.
            </p>
            
            <button 
                className="btn btn-primary" 
                onClick={loadTemplates}
                style={{ marginBottom: '20px' }}
            >
                Browse our templates
            </button>
            
            <div className="templates-grid" style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
                {templates.map((template, index) => (
                    <div key={index} className="template-card" style={{ width: '300px' }}>
                        <img 
                            src={template.Src} 
                            alt={template.Name}
                            className="template-image"
                            onError={(e) => {
                                e.target.src = 'https://via.placeholder.com/300x200?text=Template+Image';
                            }}
                        />
                        <div className="template-title">{template.Name}</div>
                        <div className="template-description">{template.Description}</div>
                        
                        <ul className="template-features">
                            {template.Features && template.Features.map((feature, idx) => (
                                <li key={idx}>{feature}</li>
                            ))}
                        </ul>
                        
                        <div className="template-price">{template.Price}</div>
                        
                        <button 
                            className="btn btn-success"
                            onClick={() => handleBuyNow(template)}
                            style={{ width: '100%' }}
                        >
                            Buy Now
                        </button>
                    </div>
                ))}
            </div>
            
            {templates.length === 0 && !loading && (
                <div className="alert alert-info">
                    No templates available. Please try refreshing the page.
                </div>
            )}
        </div>
    );
};

export default TemplateDisplay;
