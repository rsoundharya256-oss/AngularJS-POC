import React, { useState } from 'react';

const ContactForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [submitted, setSubmitted] = useState(false);
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        
        // Clear error for this field
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const validateForm = () => {
        const newErrors = {};
        
        if (!formData.name.trim()) {
            newErrors.name = 'Name is required';
        }
        
        if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'Valid email is required';
        }
        
        if (!formData.subject.trim()) {
            newErrors.subject = 'Subject is required';
        }
        
        if (!formData.message.trim()) {
            newErrors.message = 'Message is required';
        }
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) return;
        
        setSubmitting(true);
        
        try {
            let result;
            
            if (window.templateService) {
                result = await window.templateService.submitContact(formData);
            } else {
                // Fallback contact submission
                await new Promise(resolve => setTimeout(resolve, 1000));
                result = {
                    success: true,
                    messageId: 'MSG' + Date.now()
                };
            }
            
            setSubmitted(true);
            setFormData({ name: '', email: '', subject: '', message: '' });
            
            // Dispatch contact success event
            if (window.eventBus) {
                window.eventBus.emit('contact-submitted', result);
            }
            
        } catch (error) {
            console.error('Contact form error:', error);
            setErrors({ submit: 'Failed to submit contact form. Please try again.' });
        } finally {
            setSubmitting(false);
        }
    };

    if (submitted) {
        return (
            <div className="alert alert-success">
                <h4>Thank you for your message!</h4>
                <p>We have received your contact request and will get back to you soon.</p>
                <button 
                    className="btn btn-primary" 
                    onClick={() => setSubmitted(false)}
                >
                    Send Another Message
                </button>
            </div>
        );
    }

    return (
        <div className="contact-form">
            <h3>Contact Us</h3>
            <p>Have questions or need help? Send us a message and we'll get back to you as soon as possible.</p>
            
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="form-label">Name *</label>
                    <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Your full name"
                    />
                    {errors.name && (
                        <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                            {errors.name}
                        </div>
                    )}
                </div>

                <div className="form-group">
                    <label className="form-label">Email *</label>
                    <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="your.email@example.com"
                    />
                    {errors.email && (
                        <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                            {errors.email}
                        </div>
                    )}
                </div>

                <div className="form-group">
                    <label className="form-label">Subject *</label>
                    <input
                        type="text"
                        className="form-control"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="What is this about?"
                    />
                    {errors.subject && (
                        <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                            {errors.subject}
                        </div>
                    )}
                </div>

                <div className="form-group">
                    <label className="form-label">Message *</label>
                    <textarea
                        className="form-control"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Your message here..."
                        rows="5"
                    />
                    {errors.message && (
                        <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                            {errors.message}
                        </div>
                    )}
                </div>

                {errors.submit && (
                    <div className="error">
                        {errors.submit}
                    </div>
                )}

                <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={submitting}
                >
                    {submitting ? 'Sending...' : 'Send Message'}
                </button>
            </form>
        </div>
    );
};

export default ContactForm;
