import React, { useState, useEffect } from 'react';

const PaymentGateway = () => {
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [formData, setFormData] = useState({
        cardNumber: '',
        expiryDate: '',
        cvv: ''
    });
    const [errors, setErrors] = useState({});
    const [processing, setProcessing] = useState(false);
    const [paymentResult, setPaymentResult] = useState(null);

    useEffect(() => {
        // Load selected template from localStorage
        const template = localStorage.getItem('selectedTemplate');
        if (template) {
            try {
                setSelectedTemplate(JSON.parse(template));
            } catch (error) {
                console.error('Error parsing selected template:', error);
            }
        }
        
        // Listen for template selection events
        if (window.eventBus) {
            const unsubscribe = window.eventBus.on('template-selected', (template) => {
                setSelectedTemplate(template);
                localStorage.setItem('selectedTemplate', JSON.stringify(template));
            });
            
            return unsubscribe;
        }
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        
        // Clear error for this field
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const validateForm = () => {
        const newErrors = {};
        
        if (!formData.cardNumber || formData.cardNumber.replace(/\s/g, '').length < 16) {
            newErrors.cardNumber = 'Card number must be 16 digits';
        }
        
        if (!formData.expiryDate || !/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
            newErrors.expiryDate = 'Expiry date must be MM/YY format';
        }
        
        if (!formData.cvv || formData.cvv.length < 3) {
            newErrors.cvv = 'CVV must be at least 3 digits';
        }
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) return;
        
        setProcessing(true);
        
        try {
            const paymentData = {
                template: selectedTemplate,
                card: formData,
                amount: selectedTemplate?.Price
            };
            
            let result;
            
            if (window.templateService) {
                result = await window.templateService.processPayment(paymentData);
            } else {
                // Fallback payment processing
                await new Promise(resolve => setTimeout(resolve, 2000));
                result = {
                    success: true,
                    transactionId: 'TXN' + Date.now(),
                    amount: selectedTemplate?.Price,
                    template: selectedTemplate
                };
            }
            
            setPaymentResult(result);
            
            // Clear form
            setFormData({ cardNumber: '', expiryDate: '', cvv: '' });
            
            // Dispatch payment success event
            if (window.eventBus) {
                window.eventBus.emit('payment-success', result);
            }
            
        } catch (error) {
            console.error('Payment failed:', error);
            setErrors({ submit: 'Payment failed. Please try again.' });
        } finally {
            setProcessing(false);
        }
    };

    if (!selectedTemplate) {
        return (
            <div className="alert alert-info">
                <h4>No Template Selected</h4>
                <p>Please select a template first to proceed with payment.</p>
                <button 
                    className="btn btn-primary" 
                    onClick={() => window.navigateTo && window.navigateTo('/templates')}
                >
                    Browse Templates
                </button>
            </div>
        );
    }

    if (paymentResult) {
        return (
            <div className="alert alert-success">
                <h4>Payment Successful!</h4>
                <p><strong>Transaction ID:</strong> {paymentResult.transactionId}</p>
                <p><strong>Amount:</strong> {paymentResult.amount}</p>
                <p><strong>Template:</strong> {paymentResult.template?.Name}</p>
                <button 
                    className="btn btn-primary" 
                    onClick={() => {
                        setPaymentResult(null);
                        window.navigateTo && window.navigateTo('/templates');
                    }}
                >
                    Continue Shopping
                </button>
            </div>
        );
    }

    return (
        <div className="payment-gateway">
            <div className="payment-form">
                <h4>Payment Gateway</h4>
                <div style={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    <strong>Template:</strong> {selectedTemplate.Name}<br />
                    <strong>Price:</strong> {selectedTemplate.Price}
                </div>
                
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className="form-label">Card Number</label>
                        <input
                            type="text"
                            className="form-control"
                            name="cardNumber"
                            value={formData.cardNumber}
                            onChange={handleInputChange}
                            placeholder="1234 5678 9012 3456"
                            maxLength="19"
                        />
                        {errors.cardNumber && (
                            <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                                {errors.cardNumber}
                            </div>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Expiry Date</label>
                        <input
                            type="text"
                            className="form-control"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            placeholder="MM/YY"
                            maxLength="5"
                        />
                        {errors.expiryDate && (
                            <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                                {errors.expiryDate}
                            </div>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">CVV</label>
                        <input
                            type="text"
                            className="form-control"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            placeholder="123"
                            maxLength="4"
                        />
                        {errors.cvv && (
                            <div style={{ color: '#d32f2f', fontSize: '12px', marginTop: '5px' }}>
                                {errors.cvv}
                            </div>
                        )}
                    </div>

                    {errors.submit && (
                        <div className="error">
                            {errors.submit}
                        </div>
                    )}

                    <button 
                        type="submit" 
                        className="btn btn-primary" 
                        disabled={processing}
                        style={{ width: '100%' }}
                    >
                        {processing ? 'Processing...' : 'Pay Now'}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default PaymentGateway;
