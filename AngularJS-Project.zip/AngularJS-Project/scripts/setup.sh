#!/bin/bash

echo "🚀 Setting up AngularJS + React Micro-Frontend Architecture"
echo "=========================================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16+ first."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16+ is required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js version: $(node -v)"

# Install root dependencies
echo "📦 Installing root dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install root dependencies"
    exit 1
fi

# Install workspace dependencies
echo "📦 Installing workspace dependencies..."
npm run install:workspaces

if [ $? -ne 0 ]; then
    echo "❌ Failed to install workspace dependencies"
    exit 1
fi

# Create necessary directories if they don't exist
echo "📁 Creating directory structure..."
mkdir -p shared/services
mkdir -p shared/utils
mkdir -p shared/types

# Create shared package.json
echo "📝 Creating shared package.json..."
cat > shared/package.json << EOF
{
  "name": "shared-services",
  "version": "1.0.0",
  "description": "Shared services and utilities for micro-frontend architecture",
  "main": "services/authService.js",
  "scripts": {
    "build": "echo 'Shared services - no build required'"
  }
}
EOF

echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Run 'npm run dev' to start all development servers"
echo "2. Open http://localhost:3000 in your browser"
echo "3. Use credentials: admin/password to login"
echo ""
echo "📚 Available commands:"
echo "  npm run dev          - Start all development servers"
echo "  npm run dev:shell    - Start shell application only"
echo "  npm run dev:react    - Start React app only"
echo "  npm run dev:angularjs - Start AngularJS app only"
echo "  npm run build        - Build all applications"
echo "  npm start            - Start production server"
echo ""
echo "🌐 Application URLs:"
echo "  Shell (Main):        http://localhost:3000"
echo "  React App:           http://localhost:3001"
echo "  AngularJS App:       http://localhost:3002"
echo ""
echo "🎉 Happy coding!"
