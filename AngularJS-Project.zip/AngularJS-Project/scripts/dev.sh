#!/bin/bash

echo "🚀 Starting Micro-Frontend Development Environment"
echo "================================================="

# Check if dependencies are installed
if [ ! -d "node_modules" ]; then
    echo "📦 Dependencies not found. Running setup..."
    ./scripts/setup.sh
fi

echo "🔥 Starting all development servers..."
echo ""
echo "🌐 Application URLs:"
echo "  Shell (Main):        http://localhost:3000"
echo "  React App:           http://localhost:3001"
echo "  AngularJS App:       http://localhost:3002"
echo ""
echo "📝 Use credentials: admin/password to login"
echo ""
echo "Press Ctrl+C to stop all servers"
echo ""

# Start all development servers
npm run dev
