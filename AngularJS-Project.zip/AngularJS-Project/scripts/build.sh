#!/bin/bash

echo "🏗️  Building Micro-Frontend Applications"
echo "======================================="

# Clean previous builds
echo "🧹 Cleaning previous builds..."
rm -rf shell/dist
rm -rf react-app/dist
rm -rf angularjs-app/dist

# Build all applications
echo "📦 Building all applications..."
npm run build

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build completed successfully!"
    echo ""
    echo "📁 Build outputs:"
    echo "  Shell:        ./shell/dist/"
    echo "  React App:    ./react-app/dist/"
    echo "  AngularJS:    ./angularjs-app/dist/"
    echo ""
    echo "🚀 To start production server:"
    echo "  npm start"
else
    echo "❌ Build failed. Check the errors above."
    exit 1
fi
