﻿//Writing a seperate angular module for the Selling Module
(function () {
    angular.module('SellingModule', []);
})();
