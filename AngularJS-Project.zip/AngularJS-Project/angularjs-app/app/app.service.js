﻿(function () {
    angular
        .module('TemplateSellingApp')
        .factory('AppService', ['$http', 'apiurls', '$q', AppService]);

    function AppService($http, apiurls, $q) {

        var service = {
            SubmitForm: SubmitForm
        };
        return service;

        //Validating the Log-In - INTEGRATED WITH SHARED AUTH SERVICE
        function SubmitForm(userName, password) {
            // Use shared authentication service if available
            if (window.authService) {
                var deferred = $q.defer();
                
                window.authService.login({ username: userName, password: password })
                    .then(function(result) {
                        if (result.success) {
                            deferred.resolve({ data: { success: true, user: result.user } });
                        } else {
                            deferred.reject({ data: { success: false, error: result.error } });
                        }
                    })
                    .catch(function(error) {
                        deferred.reject({ data: { success: false, error: error.message } });
                    });
                
                return deferred.promise;
            }
            
            // Fallback to original hardcoded authentication
            var validUsername = 'admin';
            var validPassword = 'password';
            
            // Simulate API response with promise
            return {
                success: function(callback) {
                    var isValid = (userName === validUsername && password === validPassword);
                    setTimeout(function() {
                        callback(isValid);
                    }, 500); // Simulate network delay
                    return this;
                },
                error: function(callback) {
                    // No error callback needed for hardcoded auth
                    return this;
                }
            };
            
            /* COMMENTED OUT - ORIGINAL BACKEND CALL
            return $http({
                method: 'GET',
                url: apiurls.apiDomain + apiurls.login + apiurls.loginMethod + apiurls.userName + userName + apiurls.password + password
             });
            */
        };
    };

})();