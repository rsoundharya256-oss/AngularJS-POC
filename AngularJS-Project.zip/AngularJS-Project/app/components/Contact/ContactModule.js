﻿//Writing a seperate angular module for the Contact Us Module
(function () {
    angular.module('ContactModule', []);
})();
