﻿(function () {

    // Setting or Defining of TemplateSellingApp and injecting all its dependencies
    angular.module('TemplateSellingApp', ['ui.router', 'SellingModule', 'AboutModule', 'ContactModule']);

})();